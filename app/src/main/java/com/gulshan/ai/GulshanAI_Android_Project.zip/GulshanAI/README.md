# Gulshan AI

Initial Android command/voice prototype.

Commands included: YouTube, Chrome, Camera, Settings, Google, Hello/Namaste, plus Hindi voice recognition and text-to-speech.

Open the folder as an Android Studio project and sync Gradle.
