package com.gulshan.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 100;
    private TextView status;
    private TextToSpeech tts;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);

        TextView title = new TextView(this);
        title.setText("Gulshan AI"); title.setTextSize(30); root.addView(title);
        EditText command = new EditText(this); command.setHint("Command likho...");
        root.addView(command, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button run = new Button(this); run.setText("COMMAND CHALAO"); root.addView(run);
        Button voice = new Button(this); voice.setText("VOICE COMMAND"); root.addView(voice);
        status = new TextView(this); status.setText("Ready"); status.setTextSize(18); status.setPadding(0,24,0,0); root.addView(status);
        setContentView(root);

        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN")); });
        run.setOnClickListener(v -> executeCommand(command.getText().toString().trim()));
        voice.setOnClickListener(v -> startVoice());
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 101);
    }

    private void startVoice() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Gulshan ko command bolo");
        try { startActivityForResult(i, VOICE_REQUEST); } catch (Exception e) { speak("Voice recognition available nahi hai."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) executeCommand(r.get(0));
        }
    }

    private void executeCommand(String command) {
        if (command.isEmpty()) { speak("Command likho ya bolo."); return; }
        status.setText("Command: " + command);
        String c = command.toLowerCase(Locale.ROOT);
        if (c.contains("youtube") || c.contains("यूट्यूब")) openUrl("https://www.youtube.com");
        else if (c.contains("chrome")) {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.android.chrome");
            if (i != null) startActivity(i); else speak("Chrome phone mein nahi mila.");
        } else if (c.contains("camera") || c.contains("कैमरा")) {
            try { startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); } catch (Exception e) { speak("Camera nahi khul saka."); }
        } else if (c.contains("settings") || c.contains("सेटिंग")) startActivity(new Intent(Settings.ACTION_SETTINGS));
        else if (c.contains("google")) openUrl("https://www.google.com");
        else if (c.contains("hello") || c.contains("हेलो") || c.contains("namaste") || c.contains("नमस्ते")) speak("Namaste. Main Gulshan AI hoon.");
        else speak("Command receive ho gayi: " + command);
    }

    private void openUrl(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { speak("Ye command open nahi ho saki."); } }
    private void speak(String s) { status.setText(s); if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "gulshan"); }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
