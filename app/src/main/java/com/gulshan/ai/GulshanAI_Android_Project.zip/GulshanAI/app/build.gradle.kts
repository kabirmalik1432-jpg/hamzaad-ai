plugins { id("com.android.application") }

android {
    namespace = "com.gulshan.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gulshan.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
