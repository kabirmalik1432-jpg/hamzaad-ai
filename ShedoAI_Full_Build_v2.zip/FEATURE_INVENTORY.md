# Shedo AI feature inventory

Core AI:
- Natural-language chat
- Server-side model selection
- Conversation memory
- Voice input
- Voice output
- Image generation
- Video generation adapter + job/status endpoints
- Web-search endpoint
- Multimodal-ready image input field
- Android action proposal/confirmation framework

Planned/extension points retained:
- Long-term memory expansion
- Background/automation
- richer multimodal file understanding
- secure production authentication
- provider-specific video adapter
- richer image/video result rendering
- streaming/realtime voice
- safe phone automation
- backup/restore
- update system

No item in the requested feature list is intentionally removed; items that require an external provider or production infrastructure are represented as real integration points rather than fake functionality.
