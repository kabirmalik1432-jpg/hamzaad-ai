# Shedo AI — Full Build v2

Shedo is designed as a real AI assistant architecture, not a fixed-command demo.

Included:
- Natural-language AI chat
- Conversation memory in SQLite
- Voice input (Android SpeechRecognizer)
- Voice output (Android TextToSpeech)
- Image generation endpoint
- Video-generation provider adapter with async job/status endpoints
- Web-search endpoint
- Multimodal-ready request shape (text + optional image data URL)
- Android action proposals with confirmation requirement
- URL/app/share action support in the Android client
- Server-side API-key configuration
- Health/config endpoints
- Provider abstraction so video/image providers can be changed without rebuilding the whole app

Important:
- API keys are NOT embedded in the APK.
- Real video generation requires a supported provider API key and a provider implementation/configuration.
- The default local Android backend URL is http://10.0.2.2:8000 for an emulator. For a physical phone, replace it with the computer/server's HTTPS URL or LAN URL and configure cleartext networking only for development.
- This project is intentionally honest about external services: it does not fake video generation.

Run server:
  cd server
  python -m venv .venv
  # activate venv
  pip install -r requirements.txt
  copy .env.example .env
  uvicorn main:app --host 0.0.0.0 --port 8000

Then set OPENAI_API_KEY. For video, configure VIDEO_PROVIDER and the matching provider credentials/adapter.
