import os, json, sqlite3, uuid, time
from typing import Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv
import httpx
from openai import OpenAI

load_dotenv()
app = FastAPI(title="Shedo AI Server", version="2.0")

DB = "shedo_memory.db"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL = os.getenv("SHEDO_MODEL", "").strip()
VIDEO_PROVIDER = os.getenv("VIDEO_PROVIDER", "none").strip().lower()
VIDEO_API_KEY = os.getenv("VIDEO_API_KEY", "")
VIDEO_API_BASE = os.getenv("VIDEO_API_BASE", "").rstrip("/")
VIDEO_MODEL = os.getenv("VIDEO_MODEL", "")

def db():
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session TEXT, role TEXT, content TEXT, created REAL)""")
    c.commit()
    return c

class ChatReq(BaseModel):
    session: str = "default"
    message: str
    image_data_url: Optional[str] = None

class ImageReq(BaseModel):
    prompt: str

class VideoReq(BaseModel):
    prompt: str
    duration_seconds: Optional[int] = None
    aspect_ratio: Optional[str] = "16:9"

class ActionReq(BaseModel):
    action: str
    target: str
    confirmed: bool = False

def remember(session, role, content):
    c=db()
    c.execute("INSERT INTO messages(session,role,content,created) VALUES(?,?,?,?)",
              (session,role,content,time.time()))
    c.commit(); c.close()

def history(session, limit=40):
    c=db()
    rows=c.execute("SELECT role,content FROM messages WHERE session=? ORDER BY id DESC LIMIT ?",
                   (session,limit)).fetchall()
    c.close()
    return list(reversed(rows))

@app.get("/health")
def health():
    return {
        "ok": True,
        "ai_configured": bool(OPENAI_API_KEY),
        "video_provider": VIDEO_PROVIDER,
        "video_configured": VIDEO_PROVIDER != "none" and bool(VIDEO_API_KEY and VIDEO_API_BASE)
    }

@app.post("/chat")
def chat(req: ChatReq):
    if not OPENAI_API_KEY:
        raise HTTPException(503, "OPENAI_API_KEY is not configured on the server.")
    client = OpenAI(api_key=OPENAI_API_KEY)
    remember(req.session, "user", req.message)
    msgs = history(req.session)
    prompt = "\n".join(f"{r}: {c}" for r,c in msgs)
    content = [{"type":"input_text","text":prompt}]
    if req.image_data_url:
        content.append({"type":"input_image","image_url":req.image_data_url})
    try:
        kwargs = {"input":[{"role":"user","content":content}]}
        if MODEL:
            kwargs["model"] = MODEL
        else:
            raise HTTPException(500, "Set SHEDO_MODEL to a model supported by your API account.")
        resp = client.responses.create(**kwargs)
        answer = getattr(resp, "output_text", "") or ""
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"AI provider error: {e}")
    remember(req.session, "assistant", answer)
    return {"answer": answer, "session": req.session}

@app.post("/web")
def web_search(req: ChatReq):
    if not OPENAI_API_KEY:
        raise HTTPException(503, "OPENAI_API_KEY is not configured on the server.")
    client = OpenAI(api_key=OPENAI_API_KEY)
    try:
        kwargs={"input":req.message, "tools":[{"type":"web_search"}]}
        if MODEL: kwargs["model"]=MODEL
        else: raise HTTPException(500, "Set SHEDO_MODEL to a supported model.")
        r=client.responses.create(**kwargs)
        return {"answer": getattr(r,"output_text","") or ""}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"Web-search provider error: {e}")

@app.post("/image")
def image(req: ImageReq):
    if not OPENAI_API_KEY:
        raise HTTPException(503, "OPENAI_API_KEY is not configured on the server.")
    client=OpenAI(api_key=OPENAI_API_KEY)
    try:
        r=client.images.generate(model="gpt-image-1", prompt=req.prompt)
        b64 = r.data[0].b64_json if r.data else None
        return {"image_base64": b64}
    except Exception as e:
        raise HTTPException(502, f"Image provider error: {e}")

@app.post("/video")
async def video(req: VideoReq):
    if VIDEO_PROVIDER == "none":
        raise HTTPException(503, "VIDEO_PROVIDER is not configured. Add a real supported video provider in .env.")
    if not (VIDEO_API_KEY and VIDEO_API_BASE and VIDEO_MODEL):
        raise HTTPException(503, "Video provider is selected but its API configuration is incomplete.")
    # Generic provider adapter: the exact payload can be mapped to the provider's official API.
    # We deliberately do not invent a provider endpoint or pretend a job exists.
    payload = {"model": VIDEO_MODEL, "prompt": req.prompt}
    if req.duration_seconds is not None: payload["duration_seconds"] = req.duration_seconds
    if req.aspect_ratio: payload["aspect_ratio"] = req.aspect_ratio
    headers={"Authorization":f"Bearer {VIDEO_API_KEY}","Content-Type":"application/json"}
    try:
        async with httpx.AsyncClient(timeout=60) as x:
            r=await x.post(f"{VIDEO_API_BASE}/videos", headers=headers, json=payload)
        if r.status_code >= 400:
            raise HTTPException(r.status_code, f"Video provider rejected request: {r.text[:1000]}")
        data=r.json()
        return {"provider":VIDEO_PROVIDER,"job":data}
    except HTTPException: raise
    except Exception as e:
        raise HTTPException(502, f"Video provider connection error: {e}")

@app.get("/video/status/{job_id}")
async def video_status(job_id: str):
    if VIDEO_PROVIDER == "none" or not (VIDEO_API_KEY and VIDEO_API_BASE):
        raise HTTPException(503, "Video provider is not configured.")
    headers={"Authorization":f"Bearer {VIDEO_API_KEY}"}
    try:
        async with httpx.AsyncClient(timeout=60) as x:
            r=await x.get(f"{VIDEO_API_BASE}/videos/{job_id}", headers=headers)
        if r.status_code >= 400:
            raise HTTPException(r.status_code, r.text[:1000])
        return r.json()
    except HTTPException: raise
    except Exception as e:
        raise HTTPException(502, f"Video status error: {e}")

@app.post("/android/action")
def android_action(req: ActionReq):
    allowed={"open_url","open_app","share_text"}
    if req.action not in allowed:
        raise HTTPException(400,"Unsupported action.")
    if not req.confirmed:
        return {"requires_confirmation":True,"action":req.action,"target":req.target}
    return {"confirmed":True,"action":req.action,"target":req.target}

@app.get("/memory/{session}")
def get_memory(session: str):
    return {"session":session,"messages":[{"role":r,"content":c} for r,c in history(session,100)]}
