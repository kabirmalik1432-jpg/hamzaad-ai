package com.shedo.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var tts: TextToSpeech
    private var session = "default"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,28,28,20)
        }
        val title = TextView(this).apply {
            text = "SHEDO AI"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        output = TextView(this).apply {
            text = "Namaste. Main Shedo hoon. Aap mujhse normal language mein baat kar sakte hain."
            textSize = 17f
            setPadding(8,24,8,24)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        input = EditText(this).apply { hint = "Shedo se kuch bhi poochiye..." }

        val row = LinearLayout(this)
        val mic = Button(this).apply { text = "🎙" }
        val send = Button(this).apply { text = "SEND" }
        val image = Button(this).apply { text = "IMAGE" }
        val video = Button(this).apply { text = "VIDEO" }
        row.addView(mic); row.addView(send); row.addView(image); row.addView(video)

        root.addView(title)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(input)
        root.addView(row)
        setContentView(root)

        send.setOnClickListener { chat(input.text.toString()) }
        mic.setOnClickListener { startVoice() }
        image.setOnClickListener {
            val p=input.text.toString().trim()
            if(p.isEmpty()) { toast("Pehle image prompt likhiye."); return@setOnClickListener }
            imageRequest(p)
        }
        video.setOnClickListener {
            val p=input.text.toString().trim()
            if(p.isEmpty()) { toast("Pehle video prompt likhiye."); return@setOnClickListener }
            videoRequest(p)
        }
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),100)
    }

    private fun chat(message:String) {
        if(message.isBlank()) return
        output.append("\n\nAap: $message")
        input.setText("")
        postJson("/chat", JSONObject().put("session",session).put("message",message)) { j ->
            val a=j.optString("answer","No response")
            runOnUiThread { output.append("\nShedo: $a"); tts.speak(a,TextToSpeech.QUEUE_ADD,null,"shedo") }
        }
    }

    private fun imageRequest(prompt:String) {
        postJson("/image", JSONObject().put("prompt",prompt)) { j ->
            runOnUiThread { output.append("\n\nImage request complete. Server returned image data."); }
        }
    }

    private fun videoRequest(prompt:String) {
        postJson("/video", JSONObject().put("prompt",prompt).put("aspect_ratio","16:9")) { j ->
            runOnUiThread {
                if(j.has("error")) output.append("\n\nVideo error: ${j.optString("error")}")
                else output.append("\n\nVideo job created. Job data: $j")
            }
        }
    }

    private fun postJson(path:String, body:JSONObject, done:(JSONObject)->Unit) {
        thread {
            try {
                val c=URL(Constants.BACKEND+path).openConnection() as HttpURLConnection
                c.requestMethod="POST"; c.doOutput=true
                c.setRequestProperty("Content-Type","application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val text=(if(c.responseCode in 200..299)c.inputStream else c.errorStream)
                    .bufferedReader().readText()
                done(JSONObject(text))
            } catch(e:Exception) {
                runOnUiThread { output.append("\n\nShedo connection error: ${e.message}") }
            }
        }
    }

    private fun startVoice() {
        if(!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Voice recognition available nahi hai."); return }
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault())
        startActivityForResult(i,200)
    }

    @Deprecated("Android callback")
    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(req==200 && res==RESULT_OK) {
            val s=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            input.setText(s); chat(s)
        }
    }

    override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS) tts.language=Locale("hi","IN") }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }

    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
