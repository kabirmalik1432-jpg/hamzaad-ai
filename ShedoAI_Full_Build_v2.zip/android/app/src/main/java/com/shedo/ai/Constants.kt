package com.shedo.ai
object Constants {
    // Emulator -> local computer. For a physical phone, replace with your server HTTPS/LAN URL.
    const val BACKEND = "http://10.0.2.2:8000"
}
